/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

import java.util.ArrayList;

/**
 *
 * @author Augustine
 */
public class Location {
    private String name, desc;
    private ArrayList<Entity> personList;
    private ArrayList<Chest> chestList;
    private ArrayList<Item> itemList;
    
    public Location(String n, String desc){
        this.chestList = new ArrayList<>();
        this.itemList = new ArrayList<>();
        this.personList = new ArrayList<>();
    }
    
    public String getName() {
        return name;
    }
    public String getDesc() {
        return name;
    }
    
    public void addEntity(Entity e){
        personList.add(e); 
    }
    public void removeEntity(Entity e){
        personList.remove(e); 
    }
    public void addChest(Chest c){
        chestList.add(c);
    }
    public void removeChest(Chest c){
        chestList.remove(c); 
    }
    public void addItem(Item i){
        itemList.add(i);
    }
    public void removeItem(Item i){
        itemList.remove(i); 
    }
    
    
}
