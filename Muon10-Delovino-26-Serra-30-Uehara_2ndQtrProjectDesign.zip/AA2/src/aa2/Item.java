/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

/**
 *
 * @author Augustine
 */
public class Item{
    private String name, desc;
    private boolean pickedUpStatus;
    private int defPoints, atkPoints, hp;
    
    
    public Item(String n, String desc, int a, int d, int h){
        this.name = n;
        this.desc = desc;
        this.atkPoints = a;
        this.defPoints = d;
    }
    
    public String getName() {
        return name;
    }
    public String getDesc() {
        return name;
    }
    public int getDefPoints() {
        return defPoints;
    }
    public int getAtkPoints() {
        return atkPoints;
    }
    public int getHP() {
        return hp;
    }
    
    public void setName(String newName) {
        this.name = newName;
    }
    public void setPickedUpStatus(Boolean status) {
        this.pickedUpStatus = status;
    }
    
    public void pickUp(){
        pickedUpStatus = true;
        System.out.println("You have picked up " + this.getName());
    }
    
}
