/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

/**
 *
 * @author Augustine
 */
public class Player extends Entity {
    private int xp;
    private Location currentLocation;
    private Weapon currentWeapon;
    private Armor currentArmor;
    private int cooldown, remainingCooldown;
    
    public Player(String n, String desc, int a, int d, int h, Location l, int cd) {
        super(n, desc, a, d, h);
        this.xp = 0;
    }
    
    public void setName(String newName) throws InvalidUsernameException {
        Boolean onlyLetters = true;
        for (char c : newName.toCharArray()){
            if(!Character.isLetter(c)){
                onlyLetters = false;
                throw new InvalidUsernameException("Username must only contain letters");
            }
        }
        if(onlyLetters){
            this.name = newName;
        }
        
    }
    
    public int getCooldown() {
        return cooldown;
    }
     
    public int getRemainingCooldown() {
        return remainingCooldown;
    }
    
    public void inspect(Interactable i){
        i.interact();
    }
    
    public void grab(Item i){
        this.addItem(i);
        //when Item is grabbed it should disappear, so no exception because it is not possible to grab the item again
        i.pickUp();
    }
    
    public void equipWeapon(Weapon i) throws AlreadyEquippedException{
        //You can only equip a Weapon through a button, so no exception because it is not possible to equip an item that is not in your inventory.
        
        if (currentWeapon != i){
            baseAtk += i.getAtkPoints();
            baseDef += i.getDefPoints();
            maxHp += i.getHP();
            currentWeapon = i;
            System.out.println(i.getName() + " has been equipped!");
        }
        else {
            throw new AlreadyEquippedException("You have already equpped this item");
        }
        
    }
    
    public void equipArmor(Armor i) throws AlreadyEquippedException{
        //You can only equip Armor through a button, so no exception because it is not possible to equip an item that is not in your inventory.
        if (currentArmor != i){
            baseAtk += i.getAtkPoints();
            baseDef += i.getDefPoints();
            maxHp += i.getHP();
            currentArmor = i;
            System.out.println(i.getName() + " has been equipped!");
        }
        else {
            throw new AlreadyEquippedException("You have already equpped this item");
        }
        
    }
    
    public void drop(Item i){
        inventory.remove(i);
        if (i == currentWeapon){
            currentWeapon = null;
        }
        if (i == currentArmor){
            currentArmor = null;
        }
    }
    
    public void travel(Location l){
        currentLocation = l;
    }
    
    public void specialAttack(Entity e) throws CooldownException{
        if (remainingCooldown == 0){
            baseAtk = baseAtk * 2;
            
            remainingCooldown = cooldown;
            this.damage(e);
            baseAtk = baseAtk / 2;
        }
        else {
            System.out.println("Remaining CD: " + remainingCooldown);
            throw new CooldownException("Please wait for cooldown to finish before using the Special attack again");
        }
    }
    
    public void progressCooldown(){
        if (remainingCooldown > 0) {
            remainingCooldown--;
        }
    }
    
    public void usePotion(Potion p) throws HealthFullException{
        if(!p.getUsedStatus()){
            if(hp != maxHp){
                hp += p.getHP();
                if (hp > maxHp){
                    hp = maxHp;
                }
                p.use();
            }
            else {
                throw new HealthFullException("Health is already full");
            }
        }
    }

    public void endGame() {
        System.out.println("Game Over");
    }
    
   
    
    
    
    
}


