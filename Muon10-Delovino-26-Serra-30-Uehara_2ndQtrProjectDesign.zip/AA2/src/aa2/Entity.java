/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Augustine
 */
abstract class Entity {
    protected String name, desc;
    protected int baseAtk, baseDef, hp, maxHp;
    protected ArrayList<Item> inventory;
    


    
    
    public Entity(String n, String desc, int a, int d, int h){
        this.inventory = new ArrayList<>(20);
        this.name = n;
        this.desc = desc;
        this.baseAtk = a;
        this.baseDef = d;
        this.hp = h;
        maxHp = hp;
    }
    
    public Entity(String n, String desc, int a, int d, int h, Item item){
        this.inventory = new ArrayList<>(20);
        this.name = n;
        this.desc = desc;
        this.baseAtk = a;
        this.baseDef = d;
        this.hp = h;
        maxHp = hp;
        inventory.add(item);
    }
    
    public String getName() {
        return name;
    }
    public String getDesc() {
        return desc;
    }
    public int getMaxHP() {
        return maxHp;
    }
    public int getHP() {
        return hp;
    }
    public int getBaseAtk() {
        return baseAtk;
    }
    public int getBaseDef() {
        return baseDef;
    }
    public ArrayList<Item> getInventory(){
        return inventory;
    }
    
    public void attack(Entity e){
        this.battle((Player) this, e);
    }
    
    public void battle(Player x, Entity y){
        //hard coded battle just for demonstration
        
        x.damage(y);
        y.damage(x);
        try {
            x.specialAttack( y);
        } 
        catch (CooldownException e) {
            System.out.println(e.getMessage());
        }
        
        if (x.hp <= 0){
            System.out.println(x.getName() + " has fallen!");
            x.endGame();
            
        }
        if (y.hp <= 0){
            System.out.println(y.getName() + " has fallen!");
            
            
        }
        
        
    }
    
    public void addItem(Item i){
        inventory.add(i);
    }
    
    public void removeItem(Item i){
        //No exception if item doesn't exist in array because if it did not exist in your inventory, it is not possible to remove it from your inventory in the game.
        if (inventory.contains(i)){
            inventory.remove(i);
        }
    }
    
    public void damage(Entity e){
        int damage = this.baseAtk - e.baseDef;
        if (damage < 0){
            damage = 0;
        }
        e.hp -= damage;
        System.out.println(e.getName() + " has lost " + damage + " hp!");
        
    }
    
    public void outputInventory() {
        for (Item i : inventory){
            System.out.println(i.getName());
        }
    }
    
    

   
   
    
    
    
    
}
