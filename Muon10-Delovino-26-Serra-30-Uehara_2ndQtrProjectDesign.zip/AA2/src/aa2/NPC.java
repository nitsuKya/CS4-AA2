/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Augustine
 */
public class NPC extends Entity implements Interactable {
    private ArrayList<String> dialog;
    private Boolean wantsToGiveItem;
    
    public NPC(String n, String desc, int a, int d, int h){
        super(n, desc, a, d, h);
        this.dialog = new ArrayList<>();
        wantsToGiveItem = true;
    }
    
    public NPC(String n, String desc, int a, int d, int h, Item item, Boolean wtgi){
        super(n, desc, a, d, h, item);
        this.dialog = new ArrayList<>();
        inventory.add(item);
        wantsToGiveItem = wtgi;
    }
    
    public void dialogOut(){
        for (String currentDialog : dialog){
            System.out.println(currentDialog);
        }
        
    }
    
    public void addDialog(String s){
        dialog.add(s);
    }
    
    public void giveItem(Player p) throws InventoryFullException, ZeroItemsException {
    if(this.inventory.isEmpty()) {
        throw new ZeroItemsException();
    } else {
        List<Item> itemsToRemove = new ArrayList<>();
        for(Item item : this.inventory){
            if (!p.inventory.contains(item) && p.inventory.size() < 20){
                p.inventory.add(item);
                itemsToRemove.add(item);
            } else if (p.inventory.size() >= 20) {
                System.out.println("Could not add all items");
                throw new InventoryFullException("Inventory is full");
            }
        }
        System.out.println("You have been given: ");
        for (Item i : itemsToRemove){
            System.out.println(i.getName());
        }
        this.inventory.removeAll(itemsToRemove);
    }
    
}


    @Override
    public void interact() { 
        this.dialogOut();
        Player playerInstance = PlayerManager.getPlayerInstance();
            if (playerInstance != null && wantsToGiveItem) {
                try {
                    Scanner scanner = new Scanner(System.in);
                    System.out.println("Do you wish to accept this item?");
                    String input = scanner.nextLine().trim().toLowerCase();
                    
                    if("yes".equals(input)){
                        this.giveItem(playerInstance);
                    }
                } 
                catch (InventoryFullException e) {
                    System.out.println(e.getMessage());
                } 
                catch (ZeroItemsException e) {
                    System.out.println("NPC: I have no more items to give");
                    
                }
            } 
            
    }
}
