/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

/**
 *
 * @author Augustine
 */
public class Potion extends Item {
    private Boolean usedStatus;
    
    
    public Potion(String n, String desc, int h) {
        super(n, desc, 0, 0 , h);
    }
    
    public void use(){
        usedStatus = true;
    }
    
    public Boolean getUsedStatus() {
        return usedStatus;
    }
    
}
