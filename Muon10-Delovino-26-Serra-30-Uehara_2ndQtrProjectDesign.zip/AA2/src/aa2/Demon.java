/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

/**
 *
 * @author Augustine
 */
public class Demon extends WeaponHoldingEnemy implements Holdable {
    
    public Demon(String n, String desc, int a, int d, int h, boolean aggressive, int xp, int cd) {
        super(n, desc, a, d, h, aggressive, xp, cd);
        hasWeapon = false;
    }

    public Demon(String n, String desc, int a, int d, int h, Item item, boolean aggressive, int xp, int cd) {
        super(n, desc, a, d, h, item, aggressive, xp, cd);
        hasWeapon = true;
    }
    
    

    @Override
    public void specialMove() {
        //Will be added in the future
        
    }

    
}
