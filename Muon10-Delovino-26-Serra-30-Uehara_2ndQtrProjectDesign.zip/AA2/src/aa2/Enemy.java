/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

/**
 *
 * @author Augustine
 */
abstract class Enemy extends Entity{
    protected Boolean isAggressive; 
    protected int xp;
    protected int specialCoolDown, remainingCooldown;

    public Enemy(String n, String desc, int a, int d, int h, boolean aggressive, int xp, int cd) {
        super(n, desc, a, d, h);
        this.isAggressive = aggressive;
        this.xp = xp;
        this.specialCoolDown = cd;
    }
    
    public Enemy(String n, String desc, int a, int d, int h, Item item, boolean aggressive, int xp, int cd) {
        super(n, desc, a, d, h, item);
        this.isAggressive = aggressive;
        this.xp = xp;
        this.specialCoolDown = cd;
    }
    
    abstract public void specialMove();
    
    public int getXp(){
        return xp;
    }
    
}
