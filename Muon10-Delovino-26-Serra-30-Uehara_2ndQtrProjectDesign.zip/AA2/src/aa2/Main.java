/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aa2;

import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author Augustine
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Location location1 = new Location("Ionia", "serg");
        Player player = new Player("Belphegor", "Player", 2, 0, 20, location1, 3);
        PlayerManager.setPlayerInstance(player);
        
        
        
        //Scenario 1
        Boss boss1 = new Boss("Jigs", "big dude", 5, 0, 15, true, 5, 3);
        Weapon item2 = new Weapon("Kraken Slayer", "Crit", 3, 0, 0);
        Armor item3 = new Armor("Bramble Vest", "AD armor", 0, 2, 0);
        player.grab(item2);
        player.grab(item3);
        try {
            player.equipWeapon(item2);
        } catch (AlreadyEquippedException e) {
            System.out.println(e.getMessage());
        }
        try {
            player.equipArmor(item3);
        } catch (AlreadyEquippedException e) {
            System.out.println(e.getMessage());
        }
        player.attack(boss1);
        

        //Scenario 2
        Weapon item1 = new Weapon("Infinity Edge", "Crit", 3, 0, 0);
        NPC npc1 = new NPC("Javi", "noobie", 0, 0, 15, item1, true);
        npc1.addDialog("Hello, I am Javi.");
        npc1.addDialog("I have a Sword for you.");
        npc1.addDialog("It is the Infinity Edge. Do you want to take it?");
        
        
        player.inspect(npc1);
        player.inspect(npc1);
        
        
        
        
        //Scenario 3
        Potion potion1 = new Potion("Potion of Elixir", "Yes", 300);
        Weapon item4 = new Weapon("Blade of the Ruined King", "Revenge.", 999, 0, 999);
        Armor item5 = new Armor("Thornail", "Eye for an Eye", 0, 999, 0);
        Chest chest1 = new Chest(3);
        try {
            chest1.addItem(potion1);
        } catch (InventoryFullException e) {
            System.out.println(e.getMessage());
        }
        try {
            chest1.addItem(item4);
        } catch (InventoryFullException e) {
            System.out.println(e.getMessage());
        }
        try {
            chest1.addItem(item5);
        } catch (InventoryFullException e) {
            System.out.println(e.getMessage());
        }
        
        player.inspect(chest1);
        
        
    }
    
}
