/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

import java.util.ArrayList;

/**
 *
 * @author Augustine
 */
public class Chest implements Interactable {
    private String name, desc;
    private ArrayList<Item> slots;
    private int maxSlots;

    public Chest(int max){
        this.maxSlots = max;
        this.slots = new ArrayList<>(maxSlots);
    }
    
    
    
    
    @Override
    public void interact() {
        this.open();
    }
    
    public void open(){
        int index = 1;
        for (Item i : slots){
            System.out.println("Slot " + index + ": " + i.getName());
            index++;
        }
    }
    
    public void addItem(Item i) throws InventoryFullException{
        if (slots.size() < maxSlots) {
            slots.add(i);
            System.out.println("Item " + i.getName() + " added to the chest.");
        }
        else {
            throw new InventoryFullException("Chest is Full.");
        }
    }   
    
    
    public void removeItem(Item i){
        if (slots.contains(i)){
            slots.remove(i);
        }
        System.out.println("Item " + i.getName() + " has been removed from the chest.");
    }
    
}
