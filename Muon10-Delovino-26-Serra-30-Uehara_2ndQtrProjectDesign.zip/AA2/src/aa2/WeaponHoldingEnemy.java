/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aa2;

/**
 *
 * @author Augustine
 */
abstract class WeaponHoldingEnemy extends Enemy implements Holdable {
    protected Boolean hasWeapon;
    
    public WeaponHoldingEnemy(String n, String desc, int a, int d, int h, boolean aggressive, int xp, int cd) {
        super(n, desc, a, d, h, aggressive, xp, cd);
        hasWeapon = false;
        
    }
    
    public WeaponHoldingEnemy(String n, String desc, int a, int d, int h, Item item, boolean aggressive, int xp, int cd) {
        super(n, desc, a, d, h, item, aggressive, xp, cd);
        hasWeapon = true;
        this.inventory.add(item);
        this.hold(item);
    }
    

    @Override
    abstract public void specialMove();

    @Override
    public void hold(Item i) {
        if(hasWeapon){
            baseAtk += i.getAtkPoints();
            baseDef += i.getDefPoints();
            maxHp += i.getHP();
            i.setPickedUpStatus(true);
        }
    }
    
}